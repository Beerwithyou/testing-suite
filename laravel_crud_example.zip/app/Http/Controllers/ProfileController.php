<?php

namespace App\Http\Controllers;

use App\Models\Profile;
use Illuminate\Http\Request;

class ProfileController extends Controller
{
    public function index() {
        $profiles = Profile::all();
        return view('profiles.index', compact('profiles'));
    }

    public function create() {
        return view('profiles.create');
    }

    public function store(Request $request) {
        $request->validate([
            'name' => 'required',
            'email' => 'required|email|unique:profiles',
            'bio' => 'nullable'
        ]);
        Profile::create($request->all());
        return redirect()->route('profiles.index')->with('success', 'Profile created.');
    }

    public function show(Profile $profile) {
        return view('profiles.show', compact('profile'));
    }

    public function edit(Profile $profile) {
        return view('profiles.edit', compact('profile'));
    }

    public function update(Request $request, Profile $profile) {
        $request->validate([
            'name' => 'required',
            'email' => 'required|email|unique:profiles,email,' . $profile->id,
            'bio' => 'nullable'
        ]);
        $profile->update($request->all());
        return redirect()->route('profiles.index')->with('success', 'Profile updated.');
    }

    public function destroy(Profile $profile) {
        $profile->delete();
        return redirect()->route('profiles.index')->with('success', 'Profile deleted.');
    }
}
