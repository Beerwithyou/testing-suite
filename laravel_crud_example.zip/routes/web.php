<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\ProfileController;

Route::resource('profiles', ProfileController::class);
